package company;

public interface Mensuravel {

    default double getMedida() {
        return 0;
    }
}
